#import "Route.h"

@implementation Route

@synthesize regex;
@synthesize handler;
@synthesize target;
@synthesize selector;
@synthesize keys;

@end
