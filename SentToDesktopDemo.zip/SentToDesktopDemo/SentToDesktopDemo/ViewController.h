//
//  ViewController.h
//  SentToTheDesktopDemo
//
//  Created by 尹东博 on 16/2/23.
//  Copyright © 2016年 尹东博. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

